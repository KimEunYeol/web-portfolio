from django.apps import AppConfig


class GuestbookConfig(AppConfig):
    name = 'guestbook'
